How to play:

Use keys to open gates and progress

W A S D - Movement
Spacebar - Drop item/Honk
Escape - Quit application

https://github.com/Tsuds/Demake_Goose_Game